#pragma once

struct WordPosition {
  const char* word;
  int indices[20];
};
