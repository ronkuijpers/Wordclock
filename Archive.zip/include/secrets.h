// secrets.h
#pragma once

#define OTA_PASSWORD  "wordclockota"
#define AP_PASSWORD "wordclockAP"
