// secrets_template.h
#pragma once

#define OTA_PASSWORD  "your_ota_password"
#define AP_PASSWORD "your_ap_password"